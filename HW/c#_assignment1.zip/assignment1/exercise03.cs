﻿using System.ComponentModel;
using System.Linq.Expressions;

class exercise03
{
    public void FizzBuzz(int i)
    {
        for (int j = 1; j <= i; j++)
        {
            if (j % 3 == 0 && j % 5 == 0) Console.WriteLine("fizzbuzz");
            else if (j % 3 == 0) Console.WriteLine("fizz");
            else if (j % 5 == 0) Console.WriteLine("buzz");
            else Console.WriteLine(j);
        }
    }

//    Write a simple program that defines a variable representing a birth date and calculates

    public void CaluateAge(DateTime birthday)
    {
        DateTime today = DateTime.Now;
        TimeSpan age = today - birthday;
        int days = age.Days;
        int gap = 10000 - (days % 10000);
        DateTime nextAn = today.AddDays(gap); 
        Console.WriteLine($"You are {days}days years old!");
        Console.WriteLine($"Your next 10000 day anniversary will be {nextAn}. ");
    }

//Write a program that greets the user using the appropriate greeting for the time of day.
//Use only if , not else or switch , statements to do so. Be sure to include the following
//greetings:
//"Good Morning"
//"Good Afternoon"
//"Good Evening"
//"Good Night"

     public void GreetUser()
    {
        DateTime now = DateTime.Now;
        if (now.Hour > 6 && now.Hour < 12) Console.WriteLine("Good morning");
        if (now.Hour >= 12 && now.Hour < 18) Console.WriteLine("Good afternoon");
        if (now.Hour >= 18 && now.Hour < 20) Console.WriteLine("Good evening");
        if (now.Hour >= 20 || now.Hour < 6) Console.WriteLine("Good night");
    }

//    Write a program that prints the result of counting up to 24 using four different increments.

    public void Counting()
    {
        for (int i = 1; i <= 4; i++)
        {
            for (int j = 0; j <= 24; j += i)
            {
                Console.Write(j + ",");
            }
            Console.WriteLine();
        }
    }
}
