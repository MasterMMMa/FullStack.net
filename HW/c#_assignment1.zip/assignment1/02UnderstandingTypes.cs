﻿// See https://aka.ms/new-console-template for more information
using System;
using System.ComponentModel;
using System.Numerics;
//Create a console application project named /02UnderstandingTypes/ that outputs the
//number of bytes in memory that each of the following number types uses, and the
//minimum and maximum values they can have: sbyte, byte, short, ushort, int, uint, long,
//ulong, float, double, and decimal.

//using System.ComponentModel;

//Console.WriteLine("Outputs the nnumber of bytes in memory that each of the following number types uses: ");
//Console.WriteLine($"Size of sbyte is {sizeof(sbyte)},  Max Value is: {sbyte.MaxValue}, Min Value is: {sbyte.MinValue}.");
//Console.WriteLine($"Size of byte is {sizeof(byte)},  Max Value is: {byte.MaxValue}, Min Value is: {byte.MinValue}.");
//Console.WriteLine($"Size of short is {sizeof(short)},  Max Value is: {short.MaxValue}, Min Value is: {short.MinValue}.");
//Console.WriteLine($"Size of ushort is {sizeof(ushort)},  Max Value is: {ushort.MaxValue}, Min Value is: {ushort.MinValue}.");
//Console.WriteLine($"Size of int is {sizeof(int)},  Max Value is: {int.MaxValue}, Min Value is: {int.MinValue}.");
//Console.WriteLine($"Size of uint is {sizeof(uint)},  Max Value is: {uint.MaxValue}, Min Value is: {uint.MinValue}.");
//Console.WriteLine($"Size of long is {sizeof(long)},  Max Value is: {long.MaxValue}, Min Value is: {long.MinValue}.");
//Console.WriteLine($"Size of ulong is {sizeof(ulong)},  Max Value is: {ulong.MaxValue}, Min Value is: {ulong.MinValue}.");
//Console.WriteLine($"Size of float is {sizeof(float)},  Max Value is: {float.MaxValue}, Min Value is: {float.MinValue}.");
//Console.WriteLine($"Size of double is {sizeof(double)},  Max Value is: {double.MaxValue}, Min Value is: {double.MinValue}.");
//Console.WriteLine($"Size of decimal is {sizeof(decimal)},  Max Value is: {decimal.MaxValue}, Min Value is: {decimal.MinValue}.");

//Write program to enter an integer number of centuries and convert it to years, days, hours,
//minutes, seconds, milliseconds, microseconds, nanoseconds. Use an appropriate data
//type for every data conversion. Beware of overflows!

//Console.Write("Please enter an interger numbers: ");
//int input = Convert.ToInt32(Console.ReadLine());
//Console.WriteLine($"You entered: {input}");
//int years = input * 100;
//long days = (long)(years * 365.2425), hours = days * 24, minutes = hours * 60, seconds = minutes * 60, milliseconds = seconds * 1000;
//BigInteger microseconds = (BigInteger)milliseconds * 1000, nanoseconds = microseconds * 1000;
//Console.WriteLine($"centuries = {years} years = {days} days = hours{hours} = {minutes}minutes = {seconds}seconds = {milliseconds}milliseconds" +
//    $" = {microseconds}microseconds = {nanoseconds}nanoseconds");

////int centuries = 1 / 0;
//double centuries = 1 / 0.0;
//Console.WriteLine(centuries);

//FizzBuzz:

//FizzBuzzis a group word game for children to teach them about division. Players take turns
//to count incrementally, replacing any number divisible by three with the word /fizz/, any
//number divisible by five with the word /buzz/, and any number divisible by both with /
//fizzbuzz/.
//Create a console application in Chapter03 named Exercise03 that outputs a simulated
//FizzBuzz game counting up to 100. The output should look something like the following
//screenshot:
//What will happen if this code executes?
//int max = 500;
//for (byte i = 0; i < max; i++)
//{
//    WriteLine(i);
//}
//Create a console application and enter the preceding code. Run the console application
//and view the output. What happens?
//What code could you add (don’t change any of the preceding code) to warn us about the
//problem?
//Your program can create a random number between 1 and 3 with the following code:
//int correctNumber = new Random().Next(3) + 1;
//Write a program that generates a random number between 1 and 3 and asks the user to
//guess what the number is. Tell the user if they guess low, high, or get the correct answer.
//Also, tell the user if their answer is outside of the range of numbers that are valid guesses
//(less than 1 or more than 3). You can convert the user's typed answer from a string to an
//int using this code:
//int guessedNumber = int.Parse(Console.ReadLine());
//Note that the above code will crash the program if the user doesn't type an integer value.
//For this exercise, assume the user will only enter valid guesses.


//exercise03 ex3 = new exercise03();
//ex3.FizzBuzz(100);

int max = 500;
//for (byte i = 0; i < max; i++)
//{
//    Console.WriteLine(i);
//}


//What happens? -> The code will run and print out the numbers from 0 to 255 as a infinite loop.
// What code could you add (don’t change any of the preceding code) to warn us about the problem?
// -> Add a break statement to exit the loop when i reaches 255.

//fix it
int count = 0;
for (byte i = 0; i < max; i++)
{
    Console.WriteLine(i);
    count++;
    if (i == byte.MaxValue) break;
}
//Your program can create a random number between 1 and 3 with the following code:
//int correctNumber = new Random().Next(3) + 1;
//Write a program that generates a random number between 1 and 3 and asks the user to
//guess what the number is. Tell the user if they guess low, high, or get the correct answer.
//Also, tell the user if their answer is outside of the range of numbers that are valid guesses
//(less than 1 or more than 3). You can convert the user's typed answer from a string to an
//int using this code:
//int guessedNumber = int.Parse(Console.ReadLine());
//Note that the above code will crash the program if the user doesn't type an integer value.
//For this exercise, assume the user will only enter valid guesses.

int correctNumber = new Random().Next(3) + 1;
Console.WriteLine("Take a guess about the number, input: ");
int guessedNumber = Convert.ToInt32(Console.ReadLine());
if (guessedNumber < 1 || guessedNumber > 3)
{
    Console.WriteLine("Your guess is outside the range, it should between 1-3");
}
else if (guessedNumber < correctNumber)
{
    Console.WriteLine("You guessed low.");
}
else if (guessedNumber > correctNumber)
{
    Console.WriteLine("You guessed high.");
}
else
{
    Console.WriteLine("You guessed correct.");
}

//Print - a - Pyramid.Like the star pattern examples that we saw earlier, create a program that
//will print the following pattern: If you find yourself getting stuck, try recreating the two
//examples that we just talked about in this chapter first. They’re simpler, and you can
//compare your results with the code included above.
//This can actually be a pretty challenging problem, so here is a hint to get you going. I used
//three total loops. One big one contains two smaller loops. The bigger loop goes from line
//to line. The first of the two inner loops prints the correct number of spaces, while the
//second inner loop prints out the correct number of stars.
//*
//***
//*****
//*******
//*********

int n = 7;
for (int j = 0; j < n; j++)
{
    for (int k = 0; k < n - j; k++)
    {
        Console.Write(" ");
    }
    for (int k = 0; k < 2 * j + 1; k++)
    {
        Console.Write("*");
    }
    Console.WriteLine();
}

//Write a simple program that defines a variable representing a birth date and calculates
//how many days old the person with that birth date is currently.
//For extra credit, output the date of their next 10,000 day (about 27 years) anniversary.
//Note: once you figure out their age in days, you can calculate the days until the next
//anniversary using int daysToNextAnniversary = 10000 - (days % 10000);

exercise03 mye = new exercise03();
mye.CaluateAge(new DateTime(1990, 1, 1));

mye.GreetUser();

mye.Counting();
